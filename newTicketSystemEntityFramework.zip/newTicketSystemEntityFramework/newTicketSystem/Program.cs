﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NLog;
using System.IO;
using System.Globalization;
using System.Threading;
using System.Data.Entity;

namespace newTicketSystem
{
    class Program : IFiles
    {
        string IFiles.filePath { get; set; }
        string IFiles.enhancementsPath { get; set; }
        string IFiles.tasksPath { get; set; }

        public static string filePath = "tickets.csv";
        public static string enhancementsPath = "enhancements.csv";
        public static string tasksPath = "tasks.csv";

        static void Main(string[] args)
        {
            var logger = NLog.LogManager.GetCurrentClassLogger();
            logger.Trace("The program has started.");




            CultureInfo cultureInfo = Thread.CurrentThread.CurrentCulture;
            TextInfo textInfo = cultureInfo.TextInfo;

            TicketFile_old tickets = new TicketFile_old();
            EnhancementFile_old enhancements = new EnhancementFile_old();
            TaskFile_old tasks = new TaskFile_old();

            int selection = 0;
            string inputSelection = "";
            do
            {
                do // Check if input is 1 - 7
                {
                    Console.WriteLine("   1) Display List of Tickets\n   2) Search for Tickets\n   3) Add a Ticket\n   4) Update Tickets");
                    Console.WriteLine("Maintenance");
                    Console.WriteLine("   5) Add Users\n   6) List Users\n   7) Exit");
                    inputSelection = Console.ReadLine();
                }
                while (inputSelection != "1" && inputSelection != "2" && inputSelection != "3" 
                && inputSelection != "4" && inputSelection != "5" && inputSelection != "6"
                && inputSelection != "7");
                selection = Convert.ToInt32(inputSelection);

                if (selection == 1)
                {
                    // Display tickets
                    logger.Trace("Select 1 Display All Tickets");
                    using (var db = new EFTicketing())
                    {
                        var query = db.Tickets.OrderBy(m => m.TicketID);
                        
                        foreach (var record in query)
                        {
                            Console.WriteLine("TicketID: {0}\nSummary {1}\nPriority {2}\nStatus {3}", record.TicketID, record.Summary, record.Priority, record.Status);
                            var submittedby = record.SubmittedUser;
                            var assignee = record.AssignedUser;


                            Console.WriteLine("Submitter: {0} ", submittedby.FirstName + " " + submittedby.LastName);
                            Console.WriteLine("Assignee: {0} ", assignee.FirstName + " " + assignee.LastName);

                            // Add appropriate Attribute records if they exist for display
                            Console.WriteLine("Watchers:");
                            foreach (var user in record.WatchingUsers.Select(g => g.User))
                            {
                                Console.WriteLine(user.FirstName + " " + user.LastName);
                            }

                            // Count for Users watching the ticket
                            Console.WriteLine("Number of watchers: {0}", record.WatchingUsers.Count());

                            if (record.TicketTypeID == 1)
                            {
                                Console.WriteLine("Severity: {0} ", record.BugAttributes.Select(ba => ba.Severity).SingleOrDefault());
                            }

                            if (record.TicketTypeID == 2)
                            {
                                Console.WriteLine("Software: {0}\nCost: {1}\nReason: {2}\nEstimate: {3}",
                                record.EnhancementAttributes.Select(ea => ea.Software).SingleOrDefault(),
                                record.EnhancementAttributes.Select(ea => ea.Cost).SingleOrDefault(),
                                record.EnhancementAttributes.Select(ea => ea.Reason).SingleOrDefault(),
                                record.EnhancementAttributes.Select(ea => ea.Estimate).SingleOrDefault());
                            }

                            if (record.TicketTypeID == 3)
                            {
                                Console.WriteLine("Project Name: {0}\nDue Date: {1}",
                                record.TaskAttributes.Select(ea => ea.ProjectName).SingleOrDefault(),
                                record.TaskAttributes.Select(ea => ea.DueDate).SingleOrDefault());
                            }
                            Console.WriteLine("");
                        }
                    }
                }
                else if (selection == 2)
                {
                    using (var db = new EFTicketing())
                    {
                        // Search for Tickets
                        logger.Trace("Select 2 Search for All Types of Tickets");
                        Console.WriteLine("Enter search term for summary search");
                        string searchTerm = Console.ReadLine();
                        ///var results = db.Tickets.Where(m => m.Summary.Contains(searchTerm) && m.TicketTypeID.Equals(1));
                        var results = db.Tickets.Where(m => m.Summary.Contains(searchTerm));
                        foreach (var record in results)
                        {
                            Console.WriteLine("TicketID: {0}\nSummary {1}\nPriority {2}\nStatus {3}", record.TicketID, record.Summary, record.Priority, record.Status);
                            var submittedby = record.SubmittedUser;
                            var assignee = record.AssignedUser;


                            Console.WriteLine("Submitter: {0} ", submittedby.FirstName + " " + submittedby.LastName);
                            Console.WriteLine("Assignee: {0} ", assignee.FirstName + " " + assignee.LastName);

                            // Add appropriate Attribute records if they exist for display
                            Console.WriteLine("Watchers:");
                            foreach (var user in record.WatchingUsers.Select(g => g.User))
                            {
                                Console.WriteLine(user.FirstName + " " + user.LastName);
                            }

                            // Count for Users watching the ticket
                            Console.WriteLine("Number of watchers: {0}", record.WatchingUsers.Count());

                            if (record.TicketTypeID == 1)
                            {
                                Console.WriteLine("Severity: {0} ", record.BugAttributes.Select(ba => ba.Severity).SingleOrDefault());
                            }

                            if (record.TicketTypeID == 2)
                            {
                                Console.WriteLine("Software: {0}\nCost: {1}\nReason: {2}\nEstimate: {3}",
                                record.EnhancementAttributes.Select(ea => ea.Software).SingleOrDefault(),
                                record.EnhancementAttributes.Select(ea => ea.Cost).SingleOrDefault(),
                                record.EnhancementAttributes.Select(ea => ea.Reason).SingleOrDefault(),
                                record.EnhancementAttributes.Select(ea => ea.Estimate).SingleOrDefault());
                            }

                            if (record.TicketTypeID == 3)
                            {
                                Console.WriteLine("Project Name: {0}\nDue Date: {1}",
                                record.TaskAttributes.Select(ea => ea.ProjectName).SingleOrDefault(),
                                record.TaskAttributes.Select(ea => ea.DueDate).SingleOrDefault());
                            }
                            Console.WriteLine("");
                        }
                    }

                }
                else if (selection == 3)
                {
                    //Add ticket
                    logger.Trace("Select 3 Add Ticket");

                    using (var db = new EFTicketing())
                    {
                        Console.WriteLine("What type of media item to add? (1- Bug, 2- Enhancement, 3- Task)");
                        int type = Convert.ToInt32(Console.ReadLine());

                        var mType = db.TicketTypes.Where(tt => tt.TicketTypeID == type).SingleOrDefault();
                        
                        if (mType != null)
                        {

                        
                        Console.Write("Enter ticket summary: ");
                        string summary = Console.ReadLine();

                        string status = "";
                        do
                        {
                        Console.Write("Enter ticket status (Valid values are New, Open, Assigned or Closed): ");
                        status = CultureInfo.CurrentCulture.TextInfo.ToTitleCase(Console.ReadLine());
                        } while (status != "New" && status != "Open" && status != "Assigned" && status != "Closed");

                        string priority = "";
                        do
                        {
                            Console.Write("Enter ticket priority (Valid values are High, Medium, Low): ");
                            priority = CultureInfo.CurrentCulture.TextInfo.ToTitleCase(Console.ReadLine());
                        } while (priority != "High" && priority != "Medium" && priority != "Low");

                        int submitting = 0;
                        Console.WriteLine("For the next 3 questions, enter a user id number corresponding to these names below:");
                            foreach (var u in db.Users)
                            {
                                Console.WriteLine("UserID: {0} Name: {1} {2} Department: {3}", u.UserID, u.FirstName, u.LastName, u.Department);
                            }
                            Console.Write("Who submitted this ticket? ");

                        submitting = Convert.ToInt32(Console.ReadLine());


                        Console.Write("Who is the ticket assigned to? ");
                        int assigned = Convert.ToInt32(Console.ReadLine());

                            Ticket newRecord = new Ticket();

                            newRecord.Summary = summary;
                            newRecord.Priority = priority;
                            newRecord.Status = status;
                            newRecord.Submitter = submitting;
                            newRecord.Assigned = assigned;
                            newRecord.TicketType = mType;

                            

                            if (mType.Description == "Bug")
                            {
                                BugAttribute ba = new BugAttribute();
                                string severity = "";
                                do
                                {
                                    Console.Write("Enter ticket severity (Valid values include Urgent, High, Medium or Low): ");
                                    severity = CultureInfo.CurrentCulture.TextInfo.ToTitleCase(Console.ReadLine());
                                } while (severity != "Urgent" && severity != "High" && severity != "Normal" && severity != "Low");

                                ba.Severity = severity;
                                newRecord.BugAttributes.Add(ba);
                            }

                            if (mType.Description == "Enhancement")
                            {
                                EnhancementAttribute ea = new EnhancementAttribute();
                                string inputSoftware = "";
                                string inputCost = "";
                                string inputReason = "";
                                string inputEstimate = "";

                                Console.Write("Enter software involved in this enhancement: ");
                                inputSoftware = Console.ReadLine();

                                Console.Write("Enter the cost of this enhancement: ");
                                inputCost = Console.ReadLine();

                                Console.Write("Enter the reason for this enhancement: ");
                                inputReason = Console.ReadLine();

                                Console.Write("Enter the estimate for this enhancement: ");
                                inputEstimate = Console.ReadLine();

                                ea.Software = inputSoftware;
                                ea.Cost = inputCost;
                                ea.Reason = inputReason;
                                ea.Estimate = inputEstimate;
                                newRecord.EnhancementAttributes.Add(ea);
                            }

                            if (mType.Description == "Task")
                            {
                                TaskAttribute ta = new TaskAttribute();
                                string inputProjectName = "";
                                string inputDueDate = "";

                                Console.Write("Enter a project name for in this task: ");
                                inputProjectName = Console.ReadLine();

                                Console.Write("Enter the due date of this task: ");
                                inputDueDate = Console.ReadLine();


                                ta.ProjectName = inputProjectName;
                                ta.DueDate = inputDueDate;
                                newRecord.TaskAttributes.Add(ta);
                            }

                            int inputWatchingUserID = 0;
                        do
                        {
                                foreach (var u in db.Users)
                                {
                                    Console.WriteLine("UserID: {0} Name: {1} {2} Department: {3}", u.UserID, u.FirstName, u.LastName, u.Department);
                                }
                                Console.Write("Enter id(s) of Who is watching this ticket. (One or more id) Enter '-99' when done. Above is a list of current users:");
                                inputWatchingUserID = Convert.ToInt32(Console.ReadLine());
                            
                             if (inputWatchingUserID != -99)
                            {
                                    // Check the database for a user object that matches
                                    var wuUserID = db.Users.Where(w => w.UserID == inputWatchingUserID).SingleOrDefault();
                                    if (wuUserID != null) 
                                    {
                                        WatchingUser watchers = new WatchingUser();
                                        watchers.UserID = inputWatchingUserID;
                                        newRecord.WatchingUsers.Add(watchers);
                                    }
                            }
                        } while (inputWatchingUserID != -99);

                            db.Tickets.Add(newRecord);
                            db.SaveChanges();
                        }
                    }

                    
                    
                }
                else if (selection == 4)
                {

                    // update existing record
                    logger.Trace("Updating record");
                    Console.WriteLine("Enter search term for summary search");
                    string searchTerm = Console.ReadLine();

                    using (var db = new EFTicketing())
                    {
                        
                        //var updateMyRecord = db.Tickets.Where(m => m.Summary == searchTerm.Trim()).SingleOrDefault();
                        var updateMyRecord = db.Tickets.Where(m => m.Summary.Contains(searchTerm)).SingleOrDefault();
                        if (updateMyRecord != null)
                        {

                            
                            Console.WriteLine("Enter the new summary for the record ({0})", updateMyRecord.Summary);
                            updateMyRecord.Summary = Console.ReadLine();

                            Console.WriteLine("Enter the new priority for the record ({0})", updateMyRecord.Priority);
                            updateMyRecord.Priority = Console.ReadLine();

                            Console.WriteLine("Enter the new status for the record ({0})", updateMyRecord.Status);
                            updateMyRecord.Status = Console.ReadLine();

                            
                                foreach (var u in db.Users)
                            {
                                Console.WriteLine("UserID: {0} Name: {1} {2} Department: {3}", u.UserID, u.FirstName, u.LastName, u.Department);

                            }
                            Console.WriteLine("Enter the UserID from above for the submitter, assigned to and watchers");
                            Console.WriteLine("Enter the new submitted by for the record ({0})", updateMyRecord.Submitter);
                            updateMyRecord.Submitter = Convert.ToInt32(Console.ReadLine());

                            Console.WriteLine("Enter the new assigned to for the record ({0})", updateMyRecord.Assigned);
                            updateMyRecord.Assigned = Convert.ToInt32(Console.ReadLine()); 

                            if (updateMyRecord.TicketType.Description == "Bug")
                            {
                                // Update the movie attributes
                                BugAttribute updateBA = updateMyRecord.BugAttributes.Single();

                                Console.WriteLine("Update the severity ({0})", updateBA.Severity);
                                updateBA.Severity = Console.ReadLine();


                            }

                            if (updateMyRecord.TicketType.Description == "Enhancement")
                            {
                                // Update the movie attributes
                                EnhancementAttribute updateEA = updateMyRecord.EnhancementAttributes.Single();

                                Console.WriteLine("Update the Software ({0})", updateEA.Software);
                                updateEA.Software = Console.ReadLine();

                                Console.WriteLine("Update the Cost ({0})", updateEA.Cost);
                                updateEA.Cost = Console.ReadLine();

                                Console.WriteLine("Update the Reason ({0})", updateEA.Reason);
                                updateEA.Reason = Console.ReadLine();

                                Console.WriteLine("Update the Estimate ({0})", updateEA.Estimate);
                                updateEA.Estimate = Console.ReadLine();

                            }

                            if (updateMyRecord.TicketType.Description == "Task")
                            {
                                // Update the movie attributes
                                TaskAttribute updateTA = updateMyRecord.TaskAttributes.Single();

                                Console.WriteLine("Update the Project Name ({0})", updateTA.ProjectName);
                                updateTA.ProjectName = Console.ReadLine();

                                Console.WriteLine("Update the Due Date ({0})", updateTA.DueDate);
                                updateTA.DueDate = Console.ReadLine();
                            }

                            var users = db.WatchingUsers.Where(wu => wu.TicketID == updateMyRecord.TicketID).ToList();

                            // For each watchinguser row - remove it from the DB Context
                            users.ForEach(u => db.WatchingUsers.Remove(u));

                            int addWatchingUser = 0;
                            do
                            {
                                Console.WriteLine("Enter a watcher - when finished enter '-99'");
                                addWatchingUser = Convert.ToInt32(Console.ReadLine());

                                if (addWatchingUser != -99)
                                {
                                    var user = db.Users.Where(u => u.UserID == addWatchingUser).FirstOrDefault();

                                    if (user != null)
                                    {
                                        WatchingUser wu = new WatchingUser();
                                        wu.User = user;
                                        updateMyRecord.WatchingUsers.Add(wu);
                                    }

                                }
                            } while (addWatchingUser != -99);
                          
                            // Update the record
                            db.SaveChanges();
                        }
                    }

                }
                else if (selection == 5)
                {
                    // Allow adding of a new user to the database
                    // Get a  from the user
                    logger.Trace("Add a User");
                    Console.WriteLine("Enter the First Name of the new user");
                    string newUserFirstName = Console.ReadLine();

                    Console.WriteLine("Enter the Last Name of the new user");
                    string newUserLastName = Console.ReadLine();

                    string newUserDept = "";
                    while (newUserDept != "IT" && newUserDept != "HR" && newUserDept != "Purchasing")
                    {
                        Console.WriteLine("Enter the Department of the new user. (Valid depts are IT, HR and Purchasing)");
                        newUserDept = Console.ReadLine();
                    }
                    using (var db = new EFTicketing())
                    {
                        // Check if Genre exists or not
                        // loop through genres and compare
                        var validate = db.Users.Where(g => g.FirstName.Trim() == newUserFirstName.Trim()).Count();
                        var validate2 = db.Users.Where(g => g.LastName.Trim() == newUserLastName.Trim()).Count();

                        Console.WriteLine("First Name Count: {0}\nLast Name Count: {1}", validate, validate2);
                        logger.Debug("Validate user " + newUserFirstName + " and found: " + validate.ToString());
                        logger.Debug("Validate user " + newUserLastName + " and found: " + validate2.ToString());

                        if (validate == 0 || validate2 == 0) // if entered first name AND last name do not match a record...
                        {
                            // Add to the Genres table
                            User newU = new User();

                            newU.FirstName = newUserFirstName;
                            newU.LastName = newUserLastName;
                            newU.Department = newUserDept;
                            newU.Enabled = 1;

                            db.Users.Add(newU);
                            db.SaveChanges();
                            Console.WriteLine("User added: {0} {1}", newUserFirstName, newUserLastName);

                        }
                        else
                        {
                            Console.WriteLine("{0} {1} user already exists", newUserFirstName, newUserLastName);
                            // logger statement?
                        }
                    }
                }
                else if (selection == 6)
                {
                    logger.Trace("List Users");
                    using (var db = new EFTicketing())
                    {
                        foreach (var u in db.Users)
                        {
                            Console.WriteLine("First Name: {0}\n Last Name: {1}\nDepartment: {2}", u.FirstName, u.LastName, u.Department);
                        }
                    }
                }
                } while (selection != 7);
        }
    }
}

